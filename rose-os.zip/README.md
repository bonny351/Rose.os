# 🌹 Rose OS

Rose OS is a lightweight, appliance-grade operating system designed for Raspberry Pi.

## Build
sudo ./scripts/build.sh

## Update
rosepkg update system

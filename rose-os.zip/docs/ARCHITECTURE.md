# Rose OS Architecture
Overview of system design.

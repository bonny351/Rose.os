# Install Rose OS
Flash the built image to an SD card.

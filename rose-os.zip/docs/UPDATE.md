# Updating Rose OS
Use `rosepkg update system`.
